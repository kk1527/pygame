#   -*- coding:utf-8 -*-
#   @Time   :   2020/  /
#   @Author :   goldsunC
#   @Email  :   2428022854@qq.com
#   @Blog   :   https://blog.csdn.net/weixin_45634606

SCREEN_W,SCREEN_H = 800,600
SCREEN_SIZE = (SCREEN_W,SCREEN_H)

BG_MULTI = 2.68
PLAYER_MUTI = 2.9

GRAVITY = 1.0

FONT = 'FixedSys.ttf'
