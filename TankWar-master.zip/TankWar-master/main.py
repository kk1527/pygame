from tank_war import TankWar

if __name__ == '__main__':
    tankWar = TankWar()
    tankWar.run_game()
